/**
 * RepairModel
 * A simple data-carrier class used to populate repair information
 * before it is passed to a Repair object.
 */
public class RepairModel {
    public String CustomerName;
    public double Price;
}
