/**
 * StandardRepair
 * A standard repair charges a service fee of 5% of the repair price.
 */
public class StandardRepair extends Repair {

    public StandardRepair(RepairModel model) {
        super(model);
    }

    @Override
    public double GetServiceFee() {
        return GetPrice() * 0.05;
    }
}
