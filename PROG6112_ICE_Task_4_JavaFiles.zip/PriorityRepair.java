/**
 * PriorityRepair
 * A priority repair charges a service fee of 12% of the repair price.
 */
public class PriorityRepair extends Repair {

    public PriorityRepair(RepairModel model) {
        super(model);
    }

    @Override
    public double GetServiceFee() {
        return GetPrice() * 0.12;
    }
}
