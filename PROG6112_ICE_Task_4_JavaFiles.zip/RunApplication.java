/**
 * RunApplication
 * Technology Repair Centre console application.
 * Reads repair records from a 2D array, converts and validates the price,
 * builds the correct Repair subclass, handles invalid data through
 * exception handling, and finally sorts the valid repair totals using
 * a bubble sort.
 */
public class RunApplication {

    /**
     * Converts a raw repair data record into a Repair object.
     * Declares both exception types using a throws clause so that
     * invalid data can be handled by the calling method.
     */
    public static Repair ProcessRepair(String[] repairData) throws NumberFormatException, IllegalArgumentException {

        String customerName = repairData[0];
        String priceInput = repairData[1];
        String repairType = repairData[2];

        // If priceInput is not numeric, Double.parseDouble() throws
        // NumberFormatException, which is allowed to propagate back
        // to the calling method (no catch here).
        double price = Double.parseDouble(priceInput);

        // Throws IllegalArgumentException if the price is not usable
        ValidatePrice(price);

        RepairModel model = new RepairModel();
        model.CustomerName = customerName;
        model.Price = price;

        Repair repair;
        if (repairType.equalsIgnoreCase("STANDARD")) {
            repair = new StandardRepair(model);
        } else if (repairType.equalsIgnoreCase("PRIORITY")) {
            repair = new PriorityRepair(model);
        } else {
            throw new IllegalArgumentException("Unknown repair type: " + repairType);
        }

        return repair;
    }

    /**
     * Validates that the repair price is usable.
     * Throws IllegalArgumentException with a meaningful message
     * if the price is less than or equal to zero.
     */
    public static void ValidatePrice(double price) throws IllegalArgumentException {
        if (price <= 0) {
            throw new IllegalArgumentException("Price must be greater than zero. Invalid price: " + price);
        }
    }

    public static void main(String[] args) {

        // Two-dimensional String array storing customer name, price input and repair type
        String[][] repairData = {
            { "Lerato Mokoena", "1200", "STANDARD" },
            { "Siyabonga Dlamini", "950", "PRIORITY" },
            { "Ayanda Ndlovu", "abc", "STANDARD" }
        };

        // Repair array to hold only the valid Repair objects that were built
        Repair[] repairs = new Repair[repairData.length];
        int validCount = 0;

        System.out.println("TECHNOLOGY REPAIR PROCESSING REPORT");
        System.out.println("---------------------------------------------------");

        // Process each repair record. length is used to control the loop.
        for (int i = 0; i < repairData.length; i++) {

            try {
                Repair repair = ProcessRepair(repairData[i]);

                // Only valid Repair objects reach this point, so store it
                repairs[validCount] = repair;
                validCount++;

                // repair is declared as the abstract Repair type, but GetServiceFee()
                // (called inside GetTotal()) runs the StandardRepair or PriorityRepair
                // version depending on the actual object - this is dynamic method binding.
                System.out.println("CUSTOMER: " + repair.GetCustomerName());
                System.out.println("REPAIR TYPE: " + repairData[i][2].toUpperCase());
                System.out.printf("VAT: R%.2f%n", repair.GetVat());
                System.out.printf("TOTAL: R%.2f%n", repair.GetTotal());

            } catch (NumberFormatException e) {
                // Price input could not be converted to a double
                System.out.println("INVALID PRICE INPUT: " + repairData[i][1]);

            } catch (IllegalArgumentException e) {
                // Price was numeric but not valid (e.g. zero, negative, or bad repair type)
                System.out.println("INVALID PRICE: " + e.getMessage());

            } finally {
                // Runs after every record, whether it succeeded or an exception occurred
                System.out.println("PROCESSING ATTEMPT COMPLETED");
                System.out.println("---------------------------------------------------");
            }
        }

        // One-dimensional array of totals built only from the valid repairs
        double[] repairTotals = new double[validCount];
        for (int i = 0; i < repairTotals.length; i++) {
            repairTotals[i] = repairs[i].GetTotal();
        }

        // Bubble sort - ascending order
        for (int i = 0; i < repairTotals.length - 1; i++) {
            for (int j = 0; j < repairTotals.length - 1 - i; j++) {
                if (repairTotals[j] > repairTotals[j + 1]) {
                    double temp = repairTotals[j];
                    repairTotals[j] = repairTotals[j + 1];
                    repairTotals[j + 1] = temp;
                }
            }
        }

        StringBuilder output = new StringBuilder("SORTED REPAIR TOTALS: ");
        for (int i = 0; i < repairTotals.length; i++) {

            // Confirm the calculated total is never negative before displaying it.
            // Run the program with the -ea flag to enable assertions.
            assert repairTotals[i] >= 0 : "Repair total must not be negative";

            output.append(String.format("%.2f", repairTotals[i]));
            if (i < repairTotals.length - 1) {
                output.append(" ");
            }
        }

        System.out.println(output.toString());
        System.out.println("---------------------------------------------------");
    }
}

/*
 * ---------------------------------------------------------------------
 * CALL STACK TRACE - price input "-250"
 * ---------------------------------------------------------------------
 * This trace explains what happens if the price input "-250" is
 * processed instead of the values currently in the repairData array.
 *
 * 1. main() loops to repairData[i] where the price input is "-250" and
 *    calls ProcessRepair(repairData[i]) from inside a try block.
 *
 * 2. ProcessRepair() calls Double.parseDouble("-250"). "-250" is a
 *    valid numeric string, so no NumberFormatException is thrown and
 *    price is set to -250.0.
 *
 * 3. ProcessRepair() then calls ValidatePrice(-250.0).
 *
 * 4. Inside ValidatePrice(), the condition (price <= 0) evaluates to
 *    true, so the method executes:
 *      throw new IllegalArgumentException(
 *          "Price must be greater than zero. Invalid price: -250.0");
 *    ValidatePrice() has no try/catch of its own, so it does not
 *    handle the exception - it immediately stops executing and the
 *    exception object is passed back to whoever called it.
 *
 * 5. Control returns to ProcessRepair(), at the line that called
 *    ValidatePrice(price). ProcessRepair() also has no try/catch
 *    around that call, so it does not handle the exception either.
 *    ProcessRepair() stops executing and the exception continues
 *    propagating up the call stack to its own caller.
 *
 * 6. Control returns to main(), at the line inside the try block that
 *    called ProcessRepair(repairData[i]). This is the first point in
 *    the call stack where a matching catch block exists.
 *
 * 7. The catch (IllegalArgumentException e) block in main() catches
 *    the exception, and its message,
 *    "Price must be greater than zero. Invalid price: -250.0", is
 *    displayed to the user via e.getMessage().
 *
 * 8. Regardless of steps 1-7, the finally block in main() always
 *    executes immediately afterwards and displays
 *    "PROCESSING ATTEMPT COMPLETED", because finally runs whether the
 *    try block completed normally or an exception occurred.
 *
 * Summary of the stack (top = currently executing):
 *    ValidatePrice(-250.0)   -> throws IllegalArgumentException
 *    ProcessRepair(String[]) -> does not catch, propagates upward
 *    main(String[])          -> catches, prints message, then finally runs
 * ---------------------------------------------------------------------
 */
