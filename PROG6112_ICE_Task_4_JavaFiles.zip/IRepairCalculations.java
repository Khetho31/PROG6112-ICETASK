/**
 * IRepairCalculations
 * Defines the contract that any repair calculation class must implement.
 */
public interface IRepairCalculations {
    String GetCustomerName();
    double GetVat();
    double GetTotal();
}
