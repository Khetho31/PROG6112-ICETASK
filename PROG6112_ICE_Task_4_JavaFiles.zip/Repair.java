/**
 * Repair
 * Abstract base class that implements IRepairCalculations.
 * Uses information hiding: the customer name and price fields are private
 * and can only be reached through methods (or the protected getter used
 * by subclasses that need the price to calculate their service fee).
 */
public abstract class Repair implements IRepairCalculations {

    // Private fields - information hiding
    private String customerName;
    private double price;

    // Constructor accepts a RepairModel object and initialises the private fields
    public Repair(RepairModel model) {
        this.customerName = model.CustomerName;
        this.price = model.Price;
    }

    // Protected getter so subclasses can access the price to work out their
    // own service fee percentage, without exposing the field itself as public.
    protected double GetPrice() {
        return price;
    }

    @Override
    public String GetCustomerName() {
        return customerName;
    }

    // VAT is always calculated as 15% of the repair price
    @Override
    public double GetVat() {
        return price * 0.15;
    }

    // Every repair type calculates its service fee differently -
    // this is where dynamic method binding comes in
    public abstract double GetServiceFee();

    // Total = Price + VAT + Service Fee
    @Override
    public double GetTotal() {
        return price + GetVat() + GetServiceFee();
    }
}
